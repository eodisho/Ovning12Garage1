﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Ovn12_Garage.Models;

namespace Ovn12_Garage.Data
{
    public class Ovn12_GarageContext : DbContext
    {
        public Ovn12_GarageContext (DbContextOptions<Ovn12_GarageContext> options)
            : base(options)
        {
        }

        public DbSet<Ovn12_Garage.Models.ParkedVehicle> ParkedVehicle { get; set; }
    }
}
