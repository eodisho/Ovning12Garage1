﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Ovn12_Garage.Data;
using Ovn12_Garage.Models;

namespace Ovn12_Garage.Controllers
{
    public class ParkedVehiclesController : Controller
    {
        private readonly Ovn12_GarageContext _context;

        public ParkedVehiclesController(Ovn12_GarageContext context)
        {
            _context = context;
        }

        // [HttpGet]

        // GET: ParkedVehicles
        public async Task<IActionResult> Index(string sortOrder)
        {
            //// Some work copied from https://youtu.be/j5HGveXf7WM
            ViewData["sortOrder"] = string.IsNullOrEmpty(sortOrder) ? "RegNr" : "";

            var vehicles = _context.ParkedVehicle.AsQueryable();

            switch (sortOrder)
            {
                case "RegNr":
                    vehicles = vehicles.OrderByDescending(v => v.RegNr);
                    break;
                default:
                    vehicles = vehicles.OrderBy(v => v.RegNr);
                    break;
            }

            var sortedVehicles = await vehicles.ToListAsync();

            var overViewListModel = sortedVehicles.Select(a => new OverViewModel
            {
                Id = a.Id,
                RegNr = a.RegNr,
                VehicleType = a.VehicleType,
                ArrivalTime = a.ArrivalTime,
                ParkedTime = Convert.ToInt32((DateTime.Now - a.ArrivalTime).TotalHours)

            }).ToList();

            return View(overViewListModel);
        }


        // GET: ParkedVehicles/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var parkedVehicle = await _context.ParkedVehicle
                .FirstOrDefaultAsync(m => m.Id == id);
            if (parkedVehicle == null)
            {
                return NotFound();
            }

            return View(parkedVehicle);
        }

        // GET: ParkedVehicles/Create
        public IActionResult Create()
        {
            //SelectListItem initializing a new instance of Microsoft.AspNetCore.Mvc.Rendering.SelectListItem.
            // paramenters are text and value of this Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
            var selectList = new List<SelectListItem>();
            foreach (var v in Enum.GetValues(typeof(VehicleTypeEnum)))
            {
                selectList.Add(new SelectListItem(v.ToString(), ((int)v).ToString()));
            }
            ViewBag.VehicleTypeEnum = selectList;
            return View(); // returns create view
        }

        // POST: ParkedVehicles/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,VehicleType,RegNr,Color,Make,Model,NrOfWheels,ArrivalTime")] ParkedVehicle parkedVehicle)
        {
            // Code for RegNrExists and the first if statement copied from Victor (a student). 
            bool RegNrExists = _context.ParkedVehicle.Any
                (x => x.RegNr == parkedVehicle.RegNr && x.Id != parkedVehicle.Id);
            if (RegNrExists == true)
            {
                ModelState.AddModelError("RegNr", "Vehicle already exists");
            }

            if (ModelState.IsValid)
            {
                _context.Add(parkedVehicle);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(parkedVehicle);
        }

        // GET: ParkedVehicles/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var parkedVehicle = await _context.ParkedVehicle.FindAsync(id);
            if (parkedVehicle == null)
            {
                return NotFound();
            }
            return View(parkedVehicle);
        }

        // POST: ParkedVehicles/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,VehicleType,RegNr,Color,Make,Model,NrOfWheels,ArrivalTime")] ParkedVehicle parkedVehicle)
        {
            if (id != parkedVehicle.Id)
            {
                return NotFound();
            }
            // The first if statement is copied frome Victor (a student)
            bool RegNrExists = _context.ParkedVehicle.Any
                    (x => x.RegNr == parkedVehicle.RegNr && x.Id != parkedVehicle.Id);
            if (RegNrExists == true)
            {
                ModelState.AddModelError("RegNr", "Vehicle already exists");
            }

            else if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(parkedVehicle);
                    // _context...etc statement is copied from Victor (a student)
                    _context.Entry(parkedVehicle).Property("ArrivalTime").IsModified = false;
                    await _context.SaveChangesAsync();

                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ParkedVehicleExists(parkedVehicle.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(parkedVehicle);
        }

        // GET: ParkedVehicles/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var parkedVehicle = await _context.ParkedVehicle
                .FirstOrDefaultAsync(m => m.Id == id);
            if (parkedVehicle == null)
            {
                return NotFound();
            }

            // Change what type of model the Delete-view is expecting
            // Based on the props from parkedVehicle, create recepit

            var receipt = new ReceiptViewModel
            {
                // here were I set the price   
                RegNr = parkedVehicle.RegNr,
                Color = parkedVehicle.Color,
                Model = parkedVehicle.Model,
                Make = parkedVehicle.Make,
                ArrivalTime = parkedVehicle.ArrivalTime,
                CheckoutTime = DateTime.Now,
                ParkedTime = (int)(DateTime.Now - parkedVehicle.ArrivalTime).TotalHours,
                Price = (int)(DateTime.Now - parkedVehicle.ArrivalTime).TotalMinutes * 10 / 60,
            };
            return View(receipt);
        }

        // POST: ParkedVehicles/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var parkedVehicle = await _context.ParkedVehicle.FindAsync(id);
            _context.ParkedVehicle.Remove(parkedVehicle);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ParkedVehicleExists(int id)
        {
            return _context.ParkedVehicle.Any(e => e.Id == id);
        }

        public async Task<IActionResult> SearchVehicle(string term)
        {
            // Use term to specify your LINQ-query which only returns
            // vehicles whose type, color or make contains the string term
            // like in index, build a list of OverViewModel-objects and send it to the view

            //var overViewListModel = "";
            //var allVehicles = await _context.ParkedVehicle.ToListAsync();

            if (!string.IsNullOrEmpty(term))
            {
                
            }

            // with RegNr it shows correct result but crashes when want to delete the vehicle
            var allVehicles = await _context.ParkedVehicle.Where(a =>
            a.RegNr.ToLower() == (term.ToLower())
            //|| a.VehicleType.ToString().ToLower().Contains(term.ToLower()) 
            || a.Color.ToLower() == (term.ToLower())
            || a.ArrivalTime.ToString() ==(term.ToLower()
            )).ToListAsync();

            var overViewListModel = allVehicles.Select(a => new OverViewModel
            {
                Id = a.Id,
                RegNr = a.RegNr,
                VehicleType = a.VehicleType,
                ArrivalTime = a.ArrivalTime,
                Color = a.Color,
                ParkedTime = Convert.ToInt32((DateTime.Now - a.ArrivalTime).TotalHours),
            });
            return View(nameof(Index), overViewListModel);
        }

    }
}
