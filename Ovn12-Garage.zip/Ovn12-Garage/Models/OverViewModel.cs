﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Ovn12_Garage.Models
{
    //översiktsvy där alla parkerade fordon visas med viss grunddata:
    //Typ, RegNr, Ankomsttid, Parkeradtid
    public class OverViewModel
    {
        public int Id { get; set; }
        [Display(Name = "Vehicle type")]
        public VehicleTypeEnum VehicleType { get; set; }
        [Display(Name = "Registration Number")]
        public string RegNr { get; set; }

        public string Color { get; set; }
        [Display(Name = "Arrival time")]
        public DateTime ArrivalTime { get; set; }
        [Display(Name = "Total parked hours")]
        public int ParkedTime { get; set; }

    }
}
