﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Ovn12_Garage.Models
{
    public class ParkedVehicle
    {
        public int Id { get; set; }
        
        [Required]
        [Display(Name = "Vehicle type")]
        public VehicleTypeEnum VehicleType { get; set; }

        [Display(Name = "Registration Number")]
        [Required(AllowEmptyStrings = false)]
        public string RegNr { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(20, ErrorMessage = "Color can't be longer than 20 characters")]
        public string Color { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(20, ErrorMessage = "Make can't be longer than 20 characters")]
        public string Make { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(20, ErrorMessage = "Model can't be longer than 20 characters")]
        public string Model { get; set; }
        
        [Range (0, 30, ErrorMessage = "Vehicle must have between 0 and 30 wheels")]
        public int NrOfWheels { get; set; }
        
        [Required]
        public DateTime ArrivalTime { get; set; }



    }
}
