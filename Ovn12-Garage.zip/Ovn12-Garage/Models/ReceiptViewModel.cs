﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Ovn12_Garage.Models
{
    public class ReceiptViewModel
    {
        public int Id { get; set; }

        [Display(Name = "Vehicle type")]
        public VehicleTypeEnum VehicleType { get; set; }

        [Display (Name = "Registration number")]
        public string RegNr { get; set; }

        public string Color { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }

        [Display(Name = "Arrival time")] 
        public DateTime ArrivalTime { get; set; }

        [Display(Name = "Departure time")]
        public DateTime CheckoutTime { get; set; }
        
        [Display(Name = "Total parked hours")]
        public int ParkedTime { get; set; }

        public int Price { get; set; }
    }
}
